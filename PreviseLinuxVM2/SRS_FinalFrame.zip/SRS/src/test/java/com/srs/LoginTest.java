package com.srs;

import com.srs.Base.BaseTest;
import com.srs.Page.HomePage;
import com.srs.Page.LoginPage;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.io.IOException;

public class LoginTest extends BaseTest {

    @Test(priority = 1)
    public void LoginPage() throws IOException {

        logger=extent.startTest("Login Test");
//      prop.load(ip);

        LoginPage Lp = new LoginPage();
        Lp.login(prop.getProperty("username"), prop.getProperty("password"));
    }
}
