package com.srs.Page;

import com.srs.Base.BaseTest;

public class HomePage extends BaseTest {


}
