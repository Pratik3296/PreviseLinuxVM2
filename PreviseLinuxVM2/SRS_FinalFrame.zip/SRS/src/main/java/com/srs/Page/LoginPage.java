package com.srs.Page;
import com.srs.Base.BaseTest;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends BaseTest
{

    @FindBy(id="Input_Email")
    WebElement username;

    @FindBy(id="Input_Password")
    WebElement password;

    @FindBy(xpath="//button[@type='submit']")
    WebElement submit_button;

    @FindBy(xpath="//a[1]")
    WebElement forgotPass;


    //Initializing the Page Objects:
    public LoginPage()
    {
        PageFactory.initElements(driver , this);
    }

    public HomePage login(String un, String pwd){
        username.sendKeys(un);
        password.sendKeys(pwd);
        //loginBtn.click();
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].click();", submit_button);

        forgotPass.click();

        return new HomePage();
    }


}
