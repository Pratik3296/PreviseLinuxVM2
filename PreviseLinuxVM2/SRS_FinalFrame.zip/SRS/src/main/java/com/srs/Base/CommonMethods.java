package com.srs.Base;

import java.io.File;
import java.io.IOException;


import com.srs.Utilz.TestUtil;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.apache.commons.io.FileUtils;

public class CommonMethods extends BaseTest{
    public static File takeScreenShots(WebDriver driver, String name) {
        try {
            TakesScreenshot ts = (TakesScreenshot) (driver);
            File src = ts.getScreenshotAs(OutputType.FILE);
            File dest = new File(System.getProperty("user.dir")+ "/Reports/Screenshots/" +TestUtil.CurentDateandTime()+".png");
            FileUtils.copyFile(src, dest);
            return  dest;}
        catch (IOException e) {
            return null;}
    }
}
