package com.srs.Base;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.srs.Utilz.TestUtil;
import com.sun.org.slf4j.internal.Logger;
import com.sun.org.slf4j.internal.LoggerFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;


public class BaseTest {

    public static WebDriver driver;
    public static Properties prop;
    public static ExtentReports extent;
    public static ExtentTest logger;
    public static String method;
    public static InputStream ip;
    protected static final Logger LOGGER = LoggerFactory.getLogger(BaseTest.class);

    @BeforeTest
    public void initialization() throws IOException {

        System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+ "/src/main/resources/chromedriver.exe" );
        driver = new ChromeDriver();

        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();

        prop = new Properties();
        ip = new FileInputStream(System.getProperty("user.dir")+ "/src/main/java/com/srs"
                + "/config/config.properties");
        prop.load(ip);

        extent = new ExtentReports(System.getProperty("user.dir") +"/Reports/"+TestUtil.CurentDateandTime()+"SRS.html", true);

        driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
        driver.get(prop.getProperty("url"));


    }

    @AfterMethod(alwaysRun = true)
    public void postcondition(ITestResult res) throws InterruptedException {
        if (res.getStatus() == ITestResult.SUCCESS) {
            logger.log(LogStatus.PASS, res.getTestClass().getName() + " is Passed ");}
        else if (res.getStatus() == ITestResult.FAILURE) {
            Calendar cal = Calendar.getInstance();
            Date date = cal.getTime();
            String name = res.getName();
            File Path = CommonMethods.takeScreenShots(driver, name + " " + date);
            String screenshotPath = Path.getPath();
            screenshotPath = screenshotPath.replace(System.getProperty("user.dir")+"/Execution status/Screenshots","");
            System.out.println(screenshotPath);
            logger.log(LogStatus.FAIL, method);
            logger.log(LogStatus.FAIL, "" + res.getThrowable());
            logger.log(LogStatus.FAIL, logger.addScreenCapture(screenshotPath));
            logger.log(LogStatus.FAIL, res.getTestClass().getName() + " is Failed ");

        }
        else if (res.getStatus() == ITestResult.SKIP) {
            logger.log(LogStatus.SKIP, res.getTestClass().getName() + " is Skipped");}

        extent.endTest(logger);
    }

    @AfterTest
    public void closeBrowser() throws InterruptedException {
        extent.flush();
        extent.close();
        driver.close();
    }

    public static void reportLog(String message, int i) {
        String temp;
        temp = method;
        method = message;
        if (i != 0) {
            logger.log(LogStatus.PASS, temp);
        }
    }
}